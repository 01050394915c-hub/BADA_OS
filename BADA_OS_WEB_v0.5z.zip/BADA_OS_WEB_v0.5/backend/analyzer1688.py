from urllib.parse import urlparse


def analyze_1688_url(url: str):
    """
    1688 URL 기본 분석
    """

    if not url:
        return {
            "ok": False,
            "error": "URL이 비어 있습니다."
        }

    parsed = urlparse(url)

    if "1688.com" not in parsed.netloc:
        return {
            "ok": False,
            "error": "1688 주소가 아닙니다."
        }

    offer_id = ""

    for part in parsed.path.split("/"):
        if part.endswith(".html"):
            offer_id = part.replace(".html", "")
            break

    return {
        "ok": True,
        "offer_id": offer_id,
        "url": url
    }